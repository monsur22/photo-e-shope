<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;
use App\AdaptPost;
use DB;
use App\User;
use App\RequestPost;
use App\Product;
// use App\Product;
// use App\Product;
use Auth;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    // public function __construct()
    // {
    //     $this->middleware(['auth', 'verified']);
    // }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function __construct()
    {
    //   $this->middleware(['auth', 'verified'])->except('index');


    }
 
    public function index()
    {
        // $data=Product::where('user_id','=',Auth::user()->id)->get();
        $data=Product::where('status','=',1)->get();
        $Newest_item=Product::orderBy('id', 'desc')->take(3)->get();

        return view('Home.homecontent.homecontent',[
            'data'=>$data,
            'Newest_item'=>$Newest_item,
        ]);

    }
//  public function details(){
//     $data=Product::where('status','=',1)->get();
//     return view('Home.pages.details',[
//         // 'data'=>$data,
//         // 'Newest_item'=>$Newest_item,
//     ]);
//  }
 public function Product_by_menu($id){
    $category=Category::all();
    $data=Product::all();
    $Product_by_menu= DB::table('products')
                        ->join('categories', 'products.category', '=', 'categories.id')
                        ->select('products.*', 'categories.category_name')  
                        ->where('products.category',$id)
                        ->where('products.status',1)
                        ->get();
    return view('Home.pages.Product_by_menu',[
        'data'=>$data,
        'Product_by_menu'=>$Product_by_menu,
        'category'=>$category,


    ]);

}


public function details_by_id($id){
    $category=Category::all();
    $data = Product::find($id);
    $user=User::all();
    return view('Home.pages.details',[
        'data'=>$data,
        'category'=>$category,
        'user'=>$user,

    ]);
}

}
