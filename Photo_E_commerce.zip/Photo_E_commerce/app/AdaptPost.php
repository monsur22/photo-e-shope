<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdaptPost extends Model
{
    //
}
