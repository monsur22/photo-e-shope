<?php $__env->startSection('maincontent'); ?>
<!-- start banner Area -->

<section class="banner-area relative" id="home">	
        <div class="overlay overlay-bg"></div>
        <div class="container">				
            <div class="row d-flex align-items-center justify-content-center">
                <div class="about-content col-lg-12">
                    <h1 class="text-white">
                        Chose Your Animal				
                    </h1>	
                    <p class="text-white link-nav"><a href="<?php echo e(url('/')); ?>">Home </a>  
                        
                    </p>
                </div>	
            </div>
        </div>
    </section>
    <!-- End banner Area -->	
        
    <!-- Start cat-list Area -->
    <section class="cat-list-area section-gap">
        <div class="container">
            <div class="row">
                    <?php $__currentLoopData = $animal_by_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-6" >
                        <div class="single-cat-list">
                          <img src="<?php echo e(asset($item->image)); ?>" alt="" class="img-fluid"style="height: 340px;width:255px">
                          <a href="<?php echo e(url('animal-details-by-id/'.$item->id)); ?>">
                               
                          <div class="overlay">
                            <div class="text"><?php echo e($item->title); ?></div>
                          </div>
                        </a>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               											
            </div>
        </div>	
    </section>      

    <!-- Start calltoaction Area -->
    <section class="calltoaction-area section-gap relative">
        <div class="container">
            <div class="overlay overlay-bg"></div>						
            <div class="row align-items-center justify-content-center">
                <h1 class="text-white">Want to help? Become a Volunteer</h1>
                <p class="text-white">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    Ut enim ad minim. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.
                </p>
                <div class="buttons d-flex flex-row">
                    <a href="#" class="primary-btn text-uppercase">View pdf details</a>
                    <a href="<?php echo e(url('/volunteer')); ?>" class="primary-btn text-uppercase">Register now</a>
                </div>
            </div>
        </div>	
    </section>
    <!-- End calltoaction Area -->				
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Home.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\animaladapt\resources\views/Home/pages/adnimal_by_menu.blade.php ENDPATH**/ ?>