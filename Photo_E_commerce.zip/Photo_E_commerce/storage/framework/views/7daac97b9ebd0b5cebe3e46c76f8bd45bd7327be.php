        <header class="header" id="header">
            <div class="page-brand">
                <a class="link" href="<?php echo e(url('/')); ?>">
                    <span class="brand">Cricketer 
                        <span class="brand-tip">Bit</span>
                    </span>
                    <span class="brand-mini">CB</span>
                </a>
            </div>
            <div class="flexbox flex-1">
                <!-- START TOP-LEFT TOOLBAR-->
                <ul class="nav navbar-toolbar">
                    <li>
                        <a class="nav-link sidebar-toggler js-sidebar-toggler"><i class="ti-menu"></i></a>
                    </li>
                    <li>
                        <form class="navbar-search" action="javascript:;">
                            <div class="rel">
                                <span class="search-icon"><i class="ti-search"></i></span>
                                <input class="form-control" placeholder="Search here...">
                            </div>
                        </form>
                    </li>
                </ul>
                <!-- END TOP-LEFT TOOLBAR-->
                <!-- START TOP-RIGHT TOOLBAR-->
                <ul class="nav navbar-toolbar">
                   
                    
                    <li class="dropdown dropdown-user">
                        <a class="nav-link dropdown-toggle link" data-toggle="dropdown">
                            
                        <span><?php echo e(Auth::user()->name); ?><i class="fa fa-angle-down m-l-5"></span></i></a>
                        <ul class="dropdown-menu dropdown-menu-right">
                            
                            
                            <a class="dropdown-item"href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('frm-logout').submit();">
                                <i class="fa fa-power-off"></i> Logout
                            </a>    
                            <form id="frm-logout" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo e(csrf_field()); ?>

                            </form>
                            
                            
                        </ul>
                    </li>
                </ul>
                <!-- END TOP-RIGHT TOOLBAR-->
            </div>
        </header><?php /**PATH E:\xampp\htdocs\Cricketer_bit\resources\views/admin/includes/header.blade.php ENDPATH**/ ?>