<?php $__env->startSection('maincontent'); ?>
<div class="privacy about col-md-9">
	<h3>Chec<span>kout</span></h3>
	      <div class="checkout-right">
				<table class="timetable_sub">
					<thead>
						<tr>
							<th>SL No.</th>		
							<th>Name</th>
							<th>Image</th>
							<th>Price</th>
							
							<th>Qty</th>
							<th>Total Price</th>
							<th>Action</th>
						</tr>
					</thead>
					<?php $id=1; ?>
					<?php ($sum=0); ?>
					<?php ($sumqty=0); ?>
					<?php ($pake=0); ?>
					<?php ($weight=0); ?>
					<?php $__currentLoopData = $cartProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $CartProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tbody>
						<tr>
							<td><?php echo e($id++); ?></td>
							<?php $id=$id?>
							<td><?php echo e($CartProduct->name); ?></td>
							<td><img src="<?php echo e(asset($CartProduct->options->image)); ?>" height="auto;" width="80px;"></td>
							<td>Tk.<?php echo e($CartProduct->price); ?></td>
							
							<td>
					<form action="<?php echo e(route('updatecart')); ?>">
						<?php echo csrf_field(); ?>
					

                <input type="number" min="1"  name="qty" value="<?php echo e($CartProduct->qty); ?>"style="width:45px;" />
                 <input type="hidden" name="rowId" value="<?php echo e($CartProduct->rowId); ?>" />
                 <button class="btn btn-success btn-sm" type="submit" name="btn">Update</button>            
                 </form>
				         </td>
	                        <td>Tk.<?php echo e($total=$CartProduct->price*$CartProduct->qty); ?></td>
							<td>
								<a href="<?php echo e(route('delete-cart-item',['rowId'=>$CartProduct->rowId])); ?>" class="btn btn-danger btn-sm"><span class="glyphicon glyphicon-trash"></span></a>
							</td>
						</tr>
				</tbody>
				<?php $sum=$sum+$total ?>
				<?php $pake=$pake+$CartProduct->options->pakecharge*$CartProduct->qty ?>
				<?php $weight=$weight+$CartProduct->options->deliverytime*$CartProduct->qty ?>
				<?php $sumqty=$sumqty+$CartProduct->qty ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
			</div>
			<br>
			<div class="checkout-left">	
				<div class="col-md-4 checkout-left-basket">
					<h4>Continue to basket</h4>
					<ul>   
						<li>Total Qty<i></i><span><?php echo e($sumqty); ?></span></li>
						<li>Total Weight<i></i><span><?php echo e($weight); ?> KG</span></li>
						<li>Product Price<i></i><span><?php echo e($sum); ?> Tk</span></li>
						<li>Packaging Charge<i></i> <span><?php echo e($pake); ?> Tk.</span></li>
						<li>Delivery Charge<i></i> <span><?php echo e($ser=14*$weight); ?> Tk.</span></li>
						<li><b>Total </b><i></i> <span><b><?php echo e($orderTotal=$sum+$ser+$pake); ?> Tk.</b></span></li>
                        <?php 
                          Session::put('orderTotal',$orderTotal);
                         ?>
                          <?php 
                          Session::put('sumqty',$sumqty);
                         ?>
						</span></li>
					</ul>
				</div>
				<div class="col-md-8 address_form_agile">
					<div class="panel-group">
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
      	<?php if(Session::get('customerId')): ?>
      	<button  style="margin-top: -30px; height: 50px;" type="button" class="btn btn-primary btn-lg btn-block"><a href="<?php echo e(route('shipping')); ?>"> <span style="color: white;">CONTINUE TO CHECKOUT</span></a> </button>
      	<?php else: ?>
      	<button  style="margin-top: -30px; height: 50px;" type="button" class="btn btn-primary btn-lg btn-block"><a href="<?php echo e(route('login')); ?>"> <span style="color: white;">CONTINUE TO CHECKOUT</span></a> </button>
      	<?php endif; ?>
      </h4>
    </div>
	<div class="checkout-right-basket">
<a href="<?php echo e(url('/')); ?>"><span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>Continue to Shopping</a>
<br>
</div>
</div>
</div>
</div>
</div>

		</div>
<!-- //about -->
		</div>
		<div class="clearfix"></div>
	</div>
<!-- //banner -->
<!-- js -->
<script src="<?php echo e(asset('public/Shop/')); ?>/assets/js/jquery-1.11.1.min.js"></script>
							 <!--quantity-->
					

<!-- //js -->
<!-- script-for sticky-nav -->
	<script>
	$(document).ready(function() {
		 var navoffeset=$(".agileits_header").offset().top;
		 $(window).scroll(function(){
			var scrollpos=$(window).scrollTop(); 
			if(scrollpos >=navoffeset){
				$(".agileits_header").addClass("fixed");
			}else{
				$(".agileits_header").removeClass("fixed");
			}
		 });
		 
	});
	</script>
<!-- //script-for sticky-nav -->
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="<?php echo e(asset('public/Shop/')); ?>/assets/js/move-top.js"></script>
<script type="text/javascript" src="<?php echo e(asset('public/Shop/')); ?>/assets/js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->
<!-- Bootstrap Core JavaScript -->
<script src="<?php echo e(asset('public/Shop/')); ?>/assets/js/bootstrap.min.js"></script>
<script>
$(document).ready(function(){
    $(".dropdown").hover(            
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideDown("fast");
            $(this).toggleClass('open');        
        },
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideUp("fast");
            $(this).toggleClass('open');       
        }
    );
});
</script>
<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
								
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
	</script>
<!-- //here ends scrolling icon -->
<script src="<?php echo e(asset('public/Shop/')); ?>/assets/js/minicart.js"></script>
<script>
		paypal.minicart.render();

		paypal.minicart.cart.on('checkout', function (evt) {
			var items = this.items(),
				len = items.length,
				total = 0,
				i;

			// Count the number of each item in the cart
			for (i = 0; i < len; i++) {
				total += items[i].get('quantity');
			}

			if (total < 3) {
				alert('The minimum order quantity is 3. Please add more to your shopping cart before checking out');
				evt.preventDefault();
			}
		});

	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Home.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Photo_E_commerce\resources\views/Home/pages/check_out.blade.php ENDPATH**/ ?>