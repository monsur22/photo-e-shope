<?php $__env->startSection('maincontent'); ?>
 <SCRIPT language=Javascript>
      <!--
      function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
      //-->
   </SCRIPT>
    <div class="row">
        <div class="col-md-9 well">
           <form action="<?php echo e(url('/checkout/order')); ?>" method="post">
              <?php echo csrf_field(); ?>
          <table class="table table-bordered">
               <p style="text-align: center;"><b> Dear <?php echo e(Session::get('customerName')); ?> Please Payment <?php echo e(Session::get('orderTotal')); ?> Tk By  Only one Method</b></p><br>
             <tr>
             <td colspan="2"><input type="radio" data-toggle="collapse" data-target="#democash" name="payment_type" value="Cash"><b>Cash On Delivery</b></td>
             <td style="text-align: right;"  colspan="2" id="democash" class="collapse"> <button type="submit" name="btn" value="Confirm Order" class="btn btn-success">Confirm</button></td>
            </tr>
          </table>
        </form>

            
            

      </div>

    </div>








   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Home.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Photo_E_commerce\resources\views/Home/check_out/payment.blade.php ENDPATH**/ ?>