<?php $__env->startSection('maincontent'); ?>
<div class="product-details"><!--product-details-->
    <div class="col-sm-5">
        <div class="view-product">
            <img  src="<?php echo e(asset($data->image)); ?>" class=""height="380px"width="330px"/>
          
        </div>
        

    </div>
    <div class="col-sm-7">
        <div class="product-information"><!--/product-information-->
            
        <h2><?php echo e($data->Name); ?></h2>
           
            <img src="<?php echo e(asset('public/home')); ?>/images/product-details/rating.png" alt="" />
            <span>
                <span>US $<?php echo e($data->Price); ?></span>
                <label>Quantity:</label>
                <input type="number" name="quantity"min="1" />
                <button type="button" class="btn btn-fefault cart">
                    <i class="fa fa-shopping-cart"></i>
                    Add to cart
                </button>
            </span>
            <p>
                <b>Description:</b>
                <?php echo e($data->description); ?>

            </p>
            
            <a href=""><img src="<?php echo e(asset('public/home')); ?>/images/product-details/share.png" class="share img-responsive"  alt="" /></a>
        </div><!--/product-information-->
    </div>
</div><!--/product-details-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Home.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Photo_E_commerce\resources\views/Home/pages/details.blade.php ENDPATH**/ ?>