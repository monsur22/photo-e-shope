   <footer class="page-footer text-right">
               

      <span style="    text-align: center;
      margin: auto;">
      <b style="font-size: 14px;"> Copyright &copy; <a href=""></a>&nbsp; <?php echo date("Y") ?>.</b> <b style="font-size: 14px;">Develop by <a href=""></a></b>

      </span>
     </footer><?php /**PATH C:\xampp\htdocs\animaladapt\resources\views/admin/includes/footer.blade.php ENDPATH**/ ?>