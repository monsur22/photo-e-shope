<?php $__env->startSection('maincontent'); ?>

<section id="cart_items">
    <form action="<?php echo e(url('/shipping-adress/store')); ?>" method="post" >
	<?php echo csrf_field(); ?>
    <div class="container col-md-12">


    
            <div class="review-payment">
                    <h2>Review & Payment</h2>
                </div>
        
                <div class="table-responsive cart_info">
                  
                                <table class="table table-condensed total-result">
                                      
                                        
                                   
                                        <tr>
                                            <td><h3>You Order Total Tk.  </h3></td>
                                        <td><span><h3>$<?php echo e(Session::get('sum')); ?></h3></span></td>
                             
                                  
                                        </tr>
                                    </table>
                    
                </div>

        <div class="shopper-informations">
            <div class="row">
          
                <div class="col-sm-6 clearfix">
                    <div class="bill-to">
                        <p>Bill To</p>
                        <div class="form-one">
                     
                                <input class="form-control"type="text" name="name"placeholder="Name *">
                               <br>
                                <input class="form-control"type="text" name="email"placeholder="Email*">
                               <br>
                              
                          
                                <input class="form-control"type="text" name="phone"placeholder="Phone *">
                               <br>

                                <input class="form-control"type="text" name="address"placeholder="Address *">
                            
                        
                        </div>
                   
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="order-message">
                        <p>Shipping Order</p>
                        <textarea name="message"  placeholder="Notes about your order, Special Notes for Delivery" rows="16"></textarea>
                   
                    </div>	
                </div>					
            </div>
        </div>
        
        
    </div>
    <button type="submit"  name="submit" class="btn btn-primary btn-lg btn-block">Continue to Payment</button>  
    </form>
</section> 

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Home.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Photo_E_commerce\resources\views/Home/check_out/shiping.blade.php ENDPATH**/ ?>