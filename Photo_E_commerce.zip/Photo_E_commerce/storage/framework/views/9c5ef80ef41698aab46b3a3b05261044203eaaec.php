
    <div class="left-sidebar">
        <h2>Category</h2>
        <div class="panel-group category-products" id="accordian"><!--category-productsr-->

            <?php 
            use App\Category;
            $data=Category::all();
            ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title"><a href="<?php echo e(url('/Product-by-menu/'.$item->id)); ?>"><?php echo e($item->category_name); ?></a></h4>
                    </div>
                </div> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
           
        </div><!--/category-products-->
    
        
    
        
        
    
    </div>
<?php /**PATH E:\xampp\htdocs\Photo_E_commerce\resources\views/Home/includes/slidebar.blade.php ENDPATH**/ ?>