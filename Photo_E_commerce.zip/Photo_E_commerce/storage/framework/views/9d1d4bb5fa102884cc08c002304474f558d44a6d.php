<?php $__env->startSection('maincontent'); ?>
<div class="features_items"><!--features_items-->
    <h2 class="title text-center">Product By Category</h2>
    <?php $__currentLoopData = $Product_by_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
   
    <div class="col-sm-4">
        <div class="product-image-wrapper">
            <div class="single-products">
                    <div class="productinfo text-center">
                        <a href="<?php echo e(url('/details/'.$item->id)); ?>">
                        <img src="<?php echo e(asset($item->image)); ?>" alt=""height="255px"width="237px" />
                    </a>
                        <h2> <a href="<?php echo e(url('/details/'.$item->id)); ?>">$<?php echo e($item->Price); ?></a> </h2>
                        <p> <a href="<?php echo e(url('/details/'.$item->id)); ?>"><?php echo e($item->Name); ?></a> </p>
                        <a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
                        <a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Login First</a>

                    </div>
                    
            </div>
            <div class="choose">
                <ul class="nav nav-pills nav-justified">
                    <li><a href="#"><i class="fa fa-plus-square"></i>Add to wishlist</a></li>
                    
                </ul>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  


   
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Home.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Photo_E_commerce\resources\views/Home/pages/Product_by_menu.blade.php ENDPATH**/ ?>