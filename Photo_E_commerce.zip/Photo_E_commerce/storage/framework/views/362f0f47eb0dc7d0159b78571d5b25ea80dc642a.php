<?php $__env->startSection('content'); ?>
         
    <div class="ibox">
            <div class="ibox-head">
                    <div class="ibox-title"> Customer Order</div>
                </div>
            <div class="ibox-body">
                    <table  class="table table-striped table-bordered table-hover" id="example-table" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th>SL</th>
                                
                                <th>Order No.</th>
                                <th>Name</th>
                             
                                <th>Quantity</th>

                                <th>Total</th>
                                <th>Status</th>
                                <th>Type</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <?php $id=1;?>
                        <tbody>
                        <?php $__currentLoopData = $order_by_show; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                            <tr>
                         <td><?php echo e($id++); ?></td>
                         
                         <td>LS<?php echo e($order->id); ?></td>
                         <td><?php echo e($order->name); ?></td>
                         
                         <td><?php echo e($order->order_qty); ?></td>
                         <td><?php echo e($order->order_total); ?></td>

                         <td>
                            <?php if($order->order_status==0): ?>
                            <?php echo "Pending"?>
                            <?php elseif($order->order_status==1): ?>
                            <?php echo "Delivery"?>
                            <?php endif; ?>
                        </td>
                         <td><?php echo e($order->payment_type); ?></td>
                           <td class="text-center">
                                     <?php if($order->order_status==0): ?>
                                        <a href="<?php echo e(route('orderstatus',['id'=>$order->id])); ?>" class="btn btn-danger" title="Pending">
                                                <span class="fa fa-arrow-up"></span>
                                        </a>
                                        <?php elseif($order->order_status==1): ?>
                                        <a href="<?php echo e(route('orderstatus',['id'=>$order->id])); ?>" class="btn btn-success" title="Delivery">
                                                <span class="fa fa-arrow-down"></span>
                                            </a>
                                        <?php endif; ?>

                                   <button  class="btn btn-success" ><a href="<?php echo e(url('/order/show/'.$order->id)); ?>" target="_blank"><i class="fa fa-eye font-14"></i></a></button> 

                                  
                              </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
        </div>
</div>   


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Photo_E_commerce\resources\views/user/Order/order_show.blade.php ENDPATH**/ ?>