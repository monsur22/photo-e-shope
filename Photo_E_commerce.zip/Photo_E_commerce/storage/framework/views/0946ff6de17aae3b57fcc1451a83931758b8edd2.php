 <nav class="page-sidebar" id="sidebar">
            <div id="sidebar-collapse">
                <div class="admin-block d-flex">
                  
                </div>
                <ul class="side-menu metismenu">
                    <li>
                        <a class="active" href="<?php echo e(url('/user')); ?>"><i class="sidebar-item-icon fa fa-th-large"></i>
                            <span class="nav-label">User-Dashboard</span>
                        </a>
                    </li>
                    <li class="heading">FEATURES</li>
                    <li>
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-user-circle"></i>
                            <span class="nav-label"> Setup</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            <li><a class="" href="<?php echo e(url('/')); ?>">My Profile</a></li>                          
                         
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-bookmark"></i>
                            <span class="nav-label">Product Post </span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            <li><a class="" href="<?php echo e(url('/mypost')); ?>">My Post</a></li>                          
                            

                           
                          
                        </ul>
                    </li>
                    
                      
              
         
                  
                </ul>
            </div>
        </nav><?php /**PATH E:\xampp\htdocs\Photo_E_commerce\resources\views/user/includes/slidebar.blade.php ENDPATH**/ ?>