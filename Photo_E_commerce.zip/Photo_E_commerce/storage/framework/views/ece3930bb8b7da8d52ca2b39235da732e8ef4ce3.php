<?php $__env->startSection('content'); ?>
         
    <div class="ibox">
            <div class="ibox-head">
                    <div class="ibox-title"> Customer Order</div>
                </div>
            <div class="ibox-body">
                    <table  class="table table-striped table-bordered table-hover" id="example-table" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th>SL</th>
                                
                                <th>Date</th>
                                <th>Order No.</th>
                                
                             
                                <th>Shiping ID</th>

                                <th>Order Quantity</th>
                                <th>Total Cost</th>
                                <th>Status</th>
                                
                                
                            </tr>
                        </thead>
                        <?php $id=1;?>
                        <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                            <tr>
                         <td><?php echo e($id++); ?></td>
                         <td><?php echo e($order->order_date); ?></td>
                         <td>LS<?php echo e($order->id); ?></td>
                         
                         <td><?php echo e($order->shipping_id); ?></td>
                         <td><?php echo e($order->order_qty); ?></td>
                         <td><?php echo e($order->order_total); ?></td>

                         <td>
                            <?php if($order->order_status==0): ?>
                            <?php echo "Pending"?>
                            <?php elseif($order->order_status==1): ?>
                            <?php echo "Delivery"?>
                            <?php endif; ?>
                        </td>
                         
                           
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
        </div>
</div>   


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Photo_E_commerce\resources\views/user/Order/my_order.blade.php ENDPATH**/ ?>