<header id="header"><!--header-->
  <div class="header_top"><!--header_top-->
    <div class="container">
      <div class="row">
        <div class="col-sm-6">
          <div class="contactinfo">
            <ul class="nav nav-pills">
              <li><a href="#"><i class="fa fa-phone"></i> +123456789</a></li>
              <li><a href="#"><i class="fa fa-envelope"></i> info@mail.com</a></li>
            </ul>
          </div>
        </div>
        <div class="col-sm-6">
          <div class="social-icons pull-right">
            <ul class="nav navbar-nav">
              <li><a href="#"><i class="fa fa-facebook"></i></a></li>
              <li><a href="#"><i class="fa fa-twitter"></i></a></li>
              <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
              <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
              <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div><!--/header_top-->
  
  <div class="header-middle"><!--header-middle-->
    <div class="container">
      <div class="row">
        <div class="col-sm-4">
          <div class="logo pull-left">
          <a href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(asset('public/home')); ?>/images/0069d6b29bc8af4ec4d0feb34f4fb41f_resize.png" alt="" height="50px"width="100px" />
           
          </a>
          </div>
        
        </div>
        <div class="col-sm-8">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                  <span class="sr-only">Toggle navigation</span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                </button>
              </div>
          <div class="mainmenu pull-right">
            <ul class="nav navbar-nav collapse navbar-collapse">
              <li><a href="<?php echo e(url('/')); ?>" class="active">Home</a></li>
            <li><a href="<?php echo e(url('/checkout')); ?>"><i class="fa fa-crosshairs"></i> Checkout</a></li>
            <li><a href="<?php echo e(url('/cart')); ?>"><i class="fa fa-shopping-cart"></i> Cart(<?php echo e(Cart::count()); ?>)</a></li>
            <?php if(Auth::check() && Auth::user()->user_role == 'admin'): ?>
              <li><a href="<?php echo e(url('/admin')); ?>"title="My Account"><i class="fa fa-user"></i><?php echo e(Auth::user()->name); ?></a></li>
              <li>
                
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="form-control"type="submit">Logout</button>
                </form>	
              </li> 
            <?php elseif( Auth::check() && Auth::user()->user_role == 'user'): ?>
              <li><a href="<?php echo e(url('/user')); ?>" title="My Account"><i class="fa fa-user"></i><?php echo e(Auth::user()->name); ?> </a></li>
              <li>
                
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="form-control"type="submit">Logout</button>
                </form>	
              </li> 
            <?php else: ?>
              <li><a href="<?php echo e(url('/login')); ?>"><i class="fa fa-lock"></i> Login</a></li>
           
                <?php endif; ?>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div><!--/header-middle-->

  
</header><!--/header--><?php /**PATH E:\xampp\htdocs\Photo_E_commerce\resources\views/Home/includes/header.blade.php ENDPATH**/ ?>