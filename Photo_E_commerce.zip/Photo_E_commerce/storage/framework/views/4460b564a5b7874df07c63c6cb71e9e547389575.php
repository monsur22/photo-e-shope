<?php $__env->startSection('maincontent'); ?>
<h3 class="text-center">Shopping Cart</span></h3>

		<section id="cart_items">
				<div class="container col-md-12">
			
					<div class="table-responsive cart_info">
						<table class="table table-condensed">
							<thead>
								<tr class="cart_menu">
									<td class="">SL No.</td>
									
									<td class="image">Image</td>
								
									<td class="price">Price</td>
									<td class="quantity">Quantity</td>
									<td class="total">Total</td>
									<td class="total">Action</td>
									<td></td>
								</tr>
							</thead>
							<?php $i=1?>
							<?php ($sum=0); ?>
							<?php ($sumqty=0); ?>
							<?php ($pake=0); ?>
							<?php ($weight=0); ?>
							<?php $__currentLoopData = $cartProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $CartProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tbody>
								<tr>
									<td class="cart_product"><?php echo e($i++); ?></td>
									
									
									<td class="cart_description">
											<img src="<?php echo e(asset($CartProduct->options->image)); ?>" height="auto;" width="80px;">
									</td>
									<td class="cart_price">
										<p>$<?php echo e($CartProduct->price); ?></p>
									</td>
									<td class="cart_quantity">
											<form action="<?php echo e(route('updatecart')); ?>">
													<?php echo csrf_field(); ?>
												
							
											<input type="number" min="1"  name="qty" value="<?php echo e($CartProduct->qty); ?>"style="width:45px;" />
											 <input type="hidden" name="rowId" value="<?php echo e($CartProduct->rowId); ?>" />
											 <button class="btn btn-success btn-sm" type="submit" name="btn">Update</button>            
											 </form>
									</td>
									<td class="cart_total">
										<p class="cart_total_price">$<?php echo e($total=$CartProduct->price*$CartProduct->qty); ?></p>
									</td>
									<td class="cart_delete">
										<a class="cart_quantity_delete " href="<?php echo e(route('delete-cart-item',['rowId'=>$CartProduct->rowId])); ?>"><span class="glyphicon glyphicon-trash"></span></a>
									</td>
								</tr>
								<?php $sum=$sum+$total ?>
								<?php $sumqty=$sumqty+$CartProduct->qty ?>
		
								
								
							</tbody>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						</table>
					</div>
				</div>
			</section> <!--/#cart_items-->
		
			<section id="do_action">
				<div class="container">
					
					<div class="row">
						
						<div class="col-sm-6">
							<h3 class="text-center">CONTINUE TO BASKET</h3>
							<div class="total_area">
								<ul>
						

									<li>Cart Sub Total <span><?php echo e($sumqty); ?></span></li>
								
									
									<li>Total <span>$<?php echo e($sum); ?></span></li>
									<?php 
									Session::put('sum',$sum);
								   ?>
									<?php 
									Session::put('sumqty',$sumqty);
								   ?>
								</ul>
								<a class="btn btn-default update" href="<?php echo e(url('/home')); ?>">Continue to Shopping</a>
							<a class="btn btn-default check_out" href="<?php echo e(url('/checkout')); ?>">Check Out</a>
									
							</div>
						</div>
					</div>
				</div>
			</section><!--/#do_action-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Home.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Photo_E_commerce\resources\views/Home/check_out/check_out.blade.php ENDPATH**/ ?>