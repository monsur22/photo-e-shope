<?php $__env->startSection('content'); ?>

<div class="page-content fade-in-up">


    <div class="ibox">
            <div class="ibox-head">
                    <div class="ibox-title">Request List On My Post</div>
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter"
                            style="margin-right: 60px;">
                        Create Post
                    </button>
                </div>
            <div class="ibox-body">
                    <table class="table table-striped table-bordered table-hover" id="example-table" cellspacing="0" width="100%">
                        <thead>
                                <tr>
                                        <th>SL</th>
                                        <th>Title</th>
                                        <th>Post ID</th>
                                        <th>Image</th>
                                        <th>Address</th>
                                        <th>Request User</th>
                                        <th> User Email</th>
                                        <th>Action</th>
                
                                </tr>
                        </thead>
                      
                        <tbody>
                                <?php $i=1 ?>
                            <?php $__currentLoopData = $RequestPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($datas->title); ?></td>
                                <td>
                                    
                                    <?php echo e($datas->post_id); ?>

                                </td>
                                <td><img src="<?php echo e(asset($datas->post_image)); ?>" height="50" width="50" >
                                </td>
                                
                                <td><?php echo e($datas->post_address); ?></td>
                            <td>
                                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($datas->request_user_id==$item->id): ?>
                                <?php echo e($item->name); ?>

                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                            
                        <td><?php echo e($datas->request_user_email); ?></td>
        
        
                                <td>
                                  
                                   
                                        
                                    <?php if($datas->status==1): ?>
                                    <a href="<?php echo e(route('request_my_post_status_update',['id'=>$datas->id])); ?>" class="btn btn-success" title=" Confirm">
                                        <span class="fa fa-arrow-up"></span>
                                    </a>
                                    <?php elseif($datas->status==0): ?>
                                    <a href="<?php echo e(route('request_my_post_status_update',['id'=>$datas->id])); ?>" class="btn btn-danger" title="Not Confirm">
                                            <span class="fa fa-arrow-down"></span>
                                        </a>
                                    <?php endif; ?>
                                    
        
                                </td>
                            </tr>
        
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
                        </tbody>
                    </table>
                </div>
        </div>
        
</div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\animaladapt\resources\views/user/pages/onmyRequest.blade.php ENDPATH**/ ?>