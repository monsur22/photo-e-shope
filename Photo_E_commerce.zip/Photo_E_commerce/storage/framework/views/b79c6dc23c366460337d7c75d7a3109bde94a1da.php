<?php $__env->startSection('content'); ?>

<div class="page-content fade-in-up">

<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog"
aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">Add Post</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
        </div>
        
            <form class="form_create" name="create_form" action="<?php echo e(url('/mypost')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
            <div class="modal-body">

                    <div class="row">

                            <div class="col-sm-6 form-group">
                            <label>Category</label>
                            <select class="form-control" name="category">
                                <option value=""selected disabled>Select Category</option>
           
                                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->category_name); ?></option>
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                                
                            </select>
                        </div>
                    
                         <div class="col-sm-6 form-group">
                            <label>Title</label>
                            <input class="form-control" type="text"  name="title" >
                        </div>
                        
                        <div class="col-sm-6 form-group">
                            <label>Image</label>
                            <input class="form-control" type="file"  name="image">
                        </div>
                        <div class="col-sm-6 form-group">
                            <label>Gender</label>
                            <select class="form-control" name="gender" >
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            
                            </select>
                        </div>
                        <div class="col-sm-12 form-group">
                            <label>Address</label>
                            <textarea class="form-control"name="address" ></textarea>
                          
                        </div>
                        <div class="col-sm-12 form-group">
                            <label>Description</label>
                            <textarea class="form-control"name="description" ></textarea>
                        
                        </div>
                       
                       
                    
                      </div>
           
           
           
           
                </div>

            <div class="modal-footer">
                    <button type="reset" class="btn btn-default" >Clear</button>

                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>
    </div>
</div>
</div>

<div class="modal fade" id="edit" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Update Post</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                </div>
                <form method="POST" action="<?php echo e(url('/mypost-update')); ?>"method="post" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="modal-body">
      
                            <div class="row">

                                <div class="col-sm-6 form-group">
                                    <label>Category</label>
                                    <select class="form-control category" name="category">
                                <option value="">Select Category</option>

                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->category_name); ?></option>
                                            
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       
                                        
                                    </select>
                                </div>
                            
                                 <div class="col-sm-6 form-group">
                                    <label>Title</label>
                                    <input class="form-control title" type="text"  name="title" >
                                    <input type="hidden" name="id" class="cId">

                                </div>
                                
                                <div class="col-sm-6 form-group">
                                    <label>Image</label>
                                    <input class="form-control image" type="file"  name="image">
                                </div>
                                <div class="col-sm-6 form-group">
                                    <label>Gender</label>
                                    <select class="form-control gender" name="gender" >
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                    
                                    </select>
                                </div>
                                <div class="col-sm-12 form-group">
                                    <label>Address</label>
                                    <textarea class="form-control address"name="address"  ></textarea>
                            
                                </div>
                                <div class="col-sm-12 form-group">
                                    <label>Description</label>
                                    <textarea class="form-control description"name="description" ></textarea>
                             
                                </div>
                            
                              </div>
                   
                   
                   
                   
                        </div>

                    <div class="modal-footer">
              

                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <div class="ibox">
            <div class="ibox-head">
                    <div class="ibox-title">Post List</div>
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter"
                            style="margin-right: 60px;">
                        Create Post
                    </button>
                </div>
            <div class="ibox-body">
                    <table class="table table-striped table-bordered table-hover" id="example-table" cellspacing="0" width="100%">
                        <thead>
                                <tr>
                                        <th>SL</th>
                                        <th>Title</th>
                                        <th>Category</th>
                                        <th>Image</th>
                                        <th>Gender</th>
                                        <th>Action</th>
                
                                </tr>
                        </thead>
                      
                        <tbody>
                                <?php $i=1 ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($datas->title); ?></td>
                                <td>
                                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($datas->category==$item->id): ?>
                                        <?php echo e($item->category_name); ?>

                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </td>
                                <td><img src="<?php echo e(asset($datas->image)); ?>" height="50" width="50" >
                                </td>
                                
                                <td><?php echo e($datas->gender); ?></td>
                            
                            
        
        
                                <td>
                                  
                                    <button onclick='edit(<?php echo e($datas->id); ?>)' data-toggle="modal" id="edit" data-target="#edit" class="btn btn-success" ><span class="fa fa-pencil font-14"></span></button> 
                                        
                                    <?php if($datas->status==1): ?>
                                    <a href="<?php echo e(route('mypost_status_update',['id'=>$datas->id])); ?>" class="btn btn-success" title="Active">
                                        <span class="fa fa-arrow-up"></span>
                                    </a>
                                    <?php elseif($datas->branch_status==0): ?>
                                    <a href="<?php echo e(route('mypost_status_update',['id'=>$datas->id])); ?>" class="btn btn-danger" title="Inactive">
                                            <span class="fa fa-arrow-down"></span>
                                        </a>
                                    <?php endif; ?>
                                    <a href="<?php echo e(url('/mypost/delete/'.$datas->id)); ?>" class="btn btn-danger" title="Delete"onclick="return confirm('Are you sure to delete this?')">
                                        <span class="fa fa-trash font-14  "></span>
                                    </a>
        
                                </td>
                            </tr>
        
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
                        </tbody>
                    </table>
                </div>
        </div>
        
</div>

<script>
        function edit(id) {
                var x =id;
                
                $.ajax({
                    type:'GET',
                    url:"<?php echo e(url('/mypost-info')); ?>/"+x,
                    success:function(response){
                        console.log(response);
                        $('.category').val(response.category);
                        $('.title').val(response.title);
                        $('.cId').val(response.id);
                        $('.gender').val(response.gender);
                        $('.address').val(response.address);
                        $('.description').val(response.description);
                      
                       
                       
        
                    },
                    error:function(xhr,status,error){
                        console.log(error);
                        
                    }
        
              });
            }
        
        
        $(document).ready(function(){
           
        
        });   
             
        </script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\animaladapt\resources\views/user/pages/mypost.blade.php ENDPATH**/ ?>