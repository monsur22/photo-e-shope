<?php $__env->startSection('maincontent'); ?>
<div class="features_items"><!--features_items-->
    <h2 class="title text-center">Features Items</h2>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
   
    <div class="col-sm-4">
        <div class="product-image-wrapper">
            <div class="single-products">
                    <div class="productinfo text-center">
                        <a href="<?php echo e(url('/details/'.$item->id)); ?>">
                        <img src="<?php echo e(asset($item->image)); ?>" alt=""height="255px"width="237px" />
                        </a>
                        <h2><a href="<?php echo e(url('/details/'.$item->id)); ?>">$<?php echo e($item->Price); ?></a></h2>
                        <p><a href="<?php echo e(url('/details/'.$item->id)); ?>"><?php echo e($item->Name); ?></a></p>
                        <form action="<?php echo e(route('add-to-cart')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                        <input type="hidden" name="id"value="<?php echo e($item->id); ?>"/>
                        <input type="hidden" name="qty"value="1"min="1" />
                        
                        <button type="submit" class="btn btn-default add-to-cart">
                            <i class="fa fa-shopping-cart"></i>
                            Add to cart
                        </button>
                        
                        </form>
                    </div>
                    
            </div>
           
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  


   
    
</div><!--features_items-->



<div class="recommended_items"><!--recommended_items-->
    <h2 class="title text-center">newest items</h2>
    
    <div id="recommended-item-carousel" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
            <div class="item active">	
                <?php $__currentLoopData = $Newest_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
              
                <div class="col-sm-4">
                    <div class="product-image-wrapper">
                        <div class="single-products">
                            <div class="productinfo text-center">
                                    <a href="<?php echo e(url('/details/'.$item->id)); ?>">
                                <img src="<?php echo e(asset($item->image)); ?>" alt=""height="127px"width="255px" />
                                    </a>
                                <h2><a href="<?php echo e(url('/details/'.$item->id)); ?>">$<?php echo e($item->Price); ?></a></h2>
                                <p><a href="<?php echo e(url('/details/'.$item->id)); ?>"><?php echo e($item->title); ?></a></p>
                                <a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
                            </div>
                            
                        </div>
                    </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
            </div>
        
        </div>
         <a class="left recommended-item-control" href="#recommended-item-carousel" data-slide="prev">
            <i class="fa fa-angle-left"></i>
          </a>
          <a class="right recommended-item-control" href="#recommended-item-carousel" data-slide="next">
            <i class="fa fa-angle-right"></i>
          </a>			
    </div>
</div><!--/recommended_items-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Home.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Photo_E_commerce\resources\views/Home/homecontent/homecontent.blade.php ENDPATH**/ ?>