<table class="wp-block-table action">
    <tbody>
        <tr>
            <td>
                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                <tbody>
                <tr>
                <td align="center">
                <table border="0" cellspacing="0" cellpadding="0">
                <tbody>
                <tr>
                <td><a class="button button-<?php echo e('blue'); ?>" href="<?php echo e($url); ?>" target="_blank" rel="noopener"><?php echo e($slot); ?></a></td>
                </tr>
                </tbody>
                </table>
                </td>
                </tr>
                </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\Photo_E_commerce\resources\views/vendor/mail/html/button.blade.php ENDPATH**/ ?>