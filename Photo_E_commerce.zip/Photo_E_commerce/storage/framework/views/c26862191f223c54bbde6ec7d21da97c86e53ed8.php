<?php $__env->startSection('maincontent'); ?>
<div class="product-details"><!--product-details-->
    <div class="col-sm-5">
        <div class="view-product">
            <img  src="<?php echo e(asset($data->image)); ?>" class=""height="380px"width="330px"/>
          
        </div>
        

    </div>
    <div class="col-sm-7">
        <div class="product-information"><!--/product-information-->
            
        <h2><?php echo e($data->Name); ?></h2>
           
            <img src="<?php echo e(asset('public/home')); ?>/images/product-details/rating.png" alt="" />

            <span>
                <span>US $<?php echo e($data->Price); ?></span>
                <label>Quantity:</label>
                <form action="<?php echo e(route('add-to-cart')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                <input type="hidden" name="id"value="<?php echo e($data->id); ?>"/>
                <input type="number" name="qty"value="1"min="1" />
                <button type="submit" class="btn btn-fefault cart">
                    <i class="fa fa-shopping-cart"></i>
                    Add to cart
                </button>
                </form>
                
                
                
            </span>
            <p>
                <b>Description:</b>
                <?php echo e($data->description); ?>

            </p>
            
            
        </div><!--/product-information-->
    </div>
</div><!--/product-details-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Home.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Photo_E_commerce\resources\views/Home/pages/details.blade.php ENDPATH**/ ?>