<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\Photo_E_commerce\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>