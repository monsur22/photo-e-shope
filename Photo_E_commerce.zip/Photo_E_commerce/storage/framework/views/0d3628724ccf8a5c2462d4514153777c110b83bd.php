<tr>
    <td class="header">
        <a href="<?php echo e($url); ?>">
            Photo E-commerce
        </a>
    </td>
</tr>
<?php /**PATH C:\xampp\htdocs\Photo_E_commerce\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>