@extends('Home.master')
@section('maincontent')
<div class="product-details"><!--product-details-->
    <div class="col-sm-5">
        <div class="view-product">
            <img  src="{{asset($data->image)}}" class=""height="380px"width="330px"/>
          
        </div>
        

    </div>
    <div class="col-sm-7">
        <div class="product-information"><!--/product-information-->
            {{-- <img src="{{asset('public/home')}}/images/product-details/new.jpg" class="newarrival" alt="" /> --}}
        <h2>{{$data->Name}}</h2>
           
            <img src="{{asset('public/home')}}/images/product-details/rating.png" alt="" />

            <span>
                <span>US ${{$data->Price}}</span>
                <label>Quantity:</label>
                <form action="{{ route('add-to-cart') }}" method="post">
                    @csrf
                <input type="hidden" name="id"value="{{ $data->id }}"/>
                <input type="number" name="qty"value="1"min="1" />
                <button type="submit" class="btn btn-fefault cart">
                    <i class="fa fa-shopping-cart"></i>
                    Add to cart
                </button>
                </form>
                {{-- <input type="submit"name="submit" class="btn btn-fefault cart " value="Add to cart"/> --}}
                {{-- @if (Auth::check())
              
                @else
                <button type="button" class="btn btn-fefault cart">
                    <i class="fa fa-shopping-cart"></i>
                    Login First
                </button>   
                @endif --}}
                
            </span>
            <p>
                <b>Description:</b>
                {{$data->description}}
            </p>
            
            {{-- <a href=""><img src="{{asset('public/home')}}/images/product-details/share.png" class="share img-responsive"  alt="" /></a> --}}
        </div><!--/product-information-->
    </div>
</div><!--/product-details-->
@endsection