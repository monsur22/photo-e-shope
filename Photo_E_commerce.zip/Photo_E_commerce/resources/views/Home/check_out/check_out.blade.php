@extends('Home.master')
@section('maincontent')
<h3 class="text-center">Shopping Cart</span></h3>

		<section id="cart_items">
				<div class="container col-md-12">
			
					<div class="table-responsive cart_info">
						<table class="table table-condensed">
							<thead>
								<tr class="cart_menu">
									<td class="">SL No.</td>
									{{-- <td class="">Name</td> --}}
									<td class="image">Image</td>
								
									<td class="price">Price</td>
									<td class="quantity">Quantity</td>
									<td class="total">Total</td>
									<td class="total">Action</td>
									<td></td>
								</tr>
							</thead>
							<?php $i=1?>
							@php($sum=0)
							@php($sumqty=0)
							@php($pake=0)
							@php($weight=0)
							@foreach($cartProduct as $CartProduct)
							<tbody>
								<tr>
									<td class="cart_product">{{$i++}}</td>
									
									{{-- <td class="cart_product">{{ $CartProduct->name }}</td> --}}
									<td class="cart_description">
											<img src="{{ asset($CartProduct->options->image) }}" height="auto;" width="80px;">
									</td>
									<td class="cart_price">
										<p>${{ $CartProduct->price }}</p>
									</td>
									<td class="cart_quantity">
											<form action="{{route('updatecart')}}">
													@csrf
												
							
											<input type="number" min="1"  name="qty" value="{{$CartProduct->qty}}"style="width:45px;" />
											 <input type="hidden" name="rowId" value="{{$CartProduct->rowId}}" />
											 <button class="btn btn-success btn-sm" type="submit" name="btn">Update</button>            
											 </form>
									</td>
									<td class="cart_total">
										<p class="cart_total_price">${{$total=$CartProduct->price*$CartProduct->qty}}</p>
									</td>
									<td class="cart_delete">
										<a class="cart_quantity_delete " href="{{ route('delete-cart-item',['rowId'=>$CartProduct->rowId]) }}"><span class="glyphicon glyphicon-trash"></span></a>
									</td>
								</tr>
								<?php $sum=$sum+$total ?>
								<?php $sumqty=$sumqty+$CartProduct->qty ?>
		
								
								
							</tbody>
				@endforeach

						</table>
					</div>
				</div>
			</section> <!--/#cart_items-->
		
			<section id="do_action">
				<div class="container">
					
					<div class="row">
						
						<div class="col-sm-6">
							<h3 class="text-center">CONTINUE TO BASKET</h3>
							<div class="total_area">
								<ul>
						

									<li>Cart Sub Total <span>{{$sumqty}}</span></li>
								
									{{-- <li>Shipping Cost <span>Free</span></li> --}}
									<li>Total <span>${{$sum}}</span></li>
									<?php 
									Session::put('sum',$sum);
								   ?>
									<?php 
									Session::put('sumqty',$sumqty);
								   ?>
								</ul>
								<a class="btn btn-default update" href="{{url('/home')}}">Continue to Shopping</a>
								@if (Auth::check())
							<a class="btn btn-default check_out" href="{{url('/checkout')}}">Check Out</a>
									
								@else
							<a class="btn btn-default check_out" href="{{url('/login')}}">Check Out</a>
									
								@endif
							{{-- <a class="btn btn-default check_out" href="{{url('/checkout')}}">Check Out</a> --}}
									
							</div>
						</div>
					</div>
				</div>
			</section><!--/#do_action-->

@endsection